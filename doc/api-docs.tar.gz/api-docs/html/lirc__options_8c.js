var lirc__options_8c =
[
    [ "options_add_defaults", "lirc__options_8c.html#ab9373283ae6a21a09e9f5d5e54e25a28", null ],
    [ "options_get_app_loglevel", "lirc__options_8c.html#a2e0ec345fba828920ffe10c85d4aa9c9", null ],
    [ "options_getboolean", "lirc__options_8c.html#a333b13c75679c2afa86790b304b16100", null ],
    [ "options_getint", "lirc__options_8c.html#a1eec84b36958fc178e354b487a080865", null ],
    [ "options_getstring", "lirc__options_8c.html#a9917b4b8d7a19dc7ff99235e581a58b0", null ],
    [ "options_load", "lirc__options_8c.html#a4ae178af397fc56d63a526535bbffe5d", null ],
    [ "options_set_loglevel", "lirc__options_8c.html#a21ea46a90d52096ab0a309317312b346", null ],
    [ "options_set_opt", "lirc__options_8c.html#a6a05c88bc1c7265388606141a91d353e", null ],
    [ "options_unload", "lirc__options_8c.html#a90f379fbbe68f7cd94b115975c57a7ce", null ],
    [ "lirc_options", "lirc__options_8c.html#a2d47d46e8babed68a22a0a8505e534c8", null ]
];