var structlirc__list =
[
    [ "next", "structlirc__list.html#a6e891ca39f56e923399ed1fb52f301fd", null ],
    [ "string", "structlirc__list.html#a5c166d9a8956b6df5138ae842a66ccd2", null ]
];