var structdecode__ctx__t =
[
    [ "code", "structdecode__ctx__t.html#a1a206e5968a38e6e5286be41c037c30c", null ],
    [ "max_remaining_gap", "structdecode__ctx__t.html#ab7221813c357026846919c726cf43d73", null ],
    [ "min_remaining_gap", "structdecode__ctx__t.html#aa76a228985ce90fddd03399aceacadb5", null ],
    [ "post", "structdecode__ctx__t.html#a81e997b57167363c5cc8db496a841165", null ],
    [ "pre", "structdecode__ctx__t.html#ae52561bab1b135eda87baf242a1092a6", null ],
    [ "repeat_flag", "structdecode__ctx__t.html#a7c9bcadb5d59fb05fdad3a0cdd9b1106", null ]
];