var structdrv__enum__udev__what =
[
    [ "idProduct", "structdrv__enum__udev__what.html#acc42ffd5127f6f0a7547be1f6b0ed173", null ],
    [ "idVendor", "structdrv__enum__udev__what.html#ab33666c4907c58adf21e94859a348f62", null ],
    [ "parent_subsys", "structdrv__enum__udev__what.html#a48157cb79f408f1123644318db417377", null ],
    [ "subsystem", "structdrv__enum__udev__what.html#a470b56a7ecb6f710b0fae1b927c440ff", null ]
];