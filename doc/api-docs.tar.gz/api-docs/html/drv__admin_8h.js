var drv__admin_8h =
[
    [ "drv_guest_func", "drv__admin_8h.html#a66ecd0448214de7b954a4c0307fc1e4b", null ],
    [ "plugin_guest_func", "drv__admin_8h.html#a6c4f5bf8264931628327fe4c62a7fa46", null ],
    [ "for_each_driver", "drv__admin_8h.html#a20c8785b0c4a112a87b05eec158ecef7", null ],
    [ "for_each_plugin", "drv__admin_8h.html#aac333496b18370092de4b8a1efde53d5", null ],
    [ "hw_choose_driver", "drv__admin_8h.html#a1eaff4902d2d278d2d42e47e763c89da", null ],
    [ "hw_print_drivers", "drv__admin_8h.html#af73a4ec1270778bae0a0376af1c79b6b", null ]
];