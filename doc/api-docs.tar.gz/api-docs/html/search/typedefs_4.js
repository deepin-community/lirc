var searchData=
[
  ['plugin_5fguest_5ffunc_765',['plugin_guest_func',['../drv__admin_8h.html#a6c4f5bf8264931628327fe4c62a7fa46',1,'drv_admin.h']]]
];
