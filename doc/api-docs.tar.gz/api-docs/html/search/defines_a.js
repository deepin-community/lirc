var searchData=
[
  ['xmp_838',['XMP',['../ir__remote__types_8h.html#a21b087fdf978a6f0da138b3efbdb1cca',1,'ir_remote_types.h']]]
];
