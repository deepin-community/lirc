var searchData=
[
  ['perrorf_613',['perrorf',['../lirc__log_8c.html#abf031435b06bf0e8a87af6b2ad58f499',1,'perrorf(const char *format,...):&#160;lirc_log.c'],['../lirc__log_8h.html#abf031435b06bf0e8a87af6b2ad58f499',1,'perrorf(const char *format,...):&#160;lirc_log.c']]]
];
