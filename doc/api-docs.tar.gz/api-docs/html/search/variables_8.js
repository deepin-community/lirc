var searchData=
[
  ['ignore_5fmask_687',['ignore_mask',['../structir__remote.html#a739c26d88eb023d67353fa08dd076255',1,'ir_remote']]],
  ['info_688',['info',['../structdriver.html#a6b71523700af552255b059ff51a657e1',1,'driver']]],
  ['init_5ffunc_689',['init_func',['../structdriver.html#a8f50bcc4e1d143a05dd4eba66a4fa7bb',1,'driver']]]
];
