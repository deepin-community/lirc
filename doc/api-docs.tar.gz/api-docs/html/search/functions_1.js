var searchData=
[
  ['btn_5fstate_5fset_5fmessage_505',['btn_state_set_message',['../irrecord_8c.html#ae8ed0747eb2c2813250f6f6bd002e511',1,'btn_state_set_message(struct button_state *state, const char *fmt,...):&#160;irrecord.c'],['../irrecord_8h.html#ae8ed0747eb2c2813250f6f6bd002e511',1,'btn_state_set_message(struct button_state *state, const char *fmt,...):&#160;irrecord.c']]],
  ['button_5fstate_5finit_506',['button_state_init',['../irrecord_8c.html#a6dc19e536c08e4e174591485d5c62697',1,'button_state_init(struct button_state *state, int started_as_root):&#160;irrecord.c'],['../irrecord_8h.html#a6dc19e536c08e4e174591485d5c62697',1,'button_state_init(struct button_state *state, int started_as_root):&#160;irrecord.c']]]
];
