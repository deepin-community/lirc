var searchData=
[
  ['decode_5ffunc_665',['decode_func',['../structdriver.html#a4c8fb1671a48fb248bc8dafa90cded15',1,'driver']]],
  ['deinit_5ffunc_666',['deinit_func',['../structdriver.html#a87fb83240c2426874349f860fb8504dc',1,'driver']]],
  ['device_667',['device',['../structdriver.html#aca3bbacc48c5f27dac5568bd658afec8',1,'driver']]],
  ['device_5fhint_668',['device_hint',['../structdriver.html#ab4d02011a73f1778b63c70f45f3ab98b',1,'driver']]],
  ['driver_669',['driver',['../structir__remote.html#a00db6cb8c77235b3f30ea9cdae6239aa',1,'ir_remote']]],
  ['driver_5fversion_670',['driver_version',['../structdriver.html#a2c48ed8680d2f242dd0c018f846551b7',1,'driver']]],
  ['drv_671',['drv',['../driver_8c.html#a18548a9bde23bdaa38bd8be5ab24428f',1,'drv():&#160;driver.c'],['../drv__admin_8c.html#a18548a9bde23bdaa38bd8be5ab24428f',1,'drv():&#160;driver.c']]],
  ['drv_5fnull_672',['drv_null',['../drv__admin_8c.html#a4812505d2b58c85f504503c9cbc3ef45',1,'drv_admin.c']]],
  ['drvctl_5ffunc_673',['drvctl_func',['../structdriver.html#ac5d035961037ecb0a74182dd456ced26',1,'driver']]],
  ['duty_5fcycle_674',['duty_cycle',['../structir__remote.html#a3edd8099b0f26ca703b051479329446a',1,'ir_remote']]],
  ['dyncode_675',['dyncode',['../structir__remote.html#ae8172a416ed4f0481f61aaee32b3803c',1,'ir_remote']]],
  ['dyncodes_676',['dyncodes',['../structir__remote.html#a250d88b2da87c39fc420714afc93c7f6',1,'ir_remote']]],
  ['dyncodes_5fname_677',['dyncodes_name',['../structir__remote.html#ac41de5381ae0049f897137be727572be',1,'ir_remote']]]
];
