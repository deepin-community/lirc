var searchData=
[
  ['_5fclient_2ec_454',['_client.c',['../__client_8c.html',1,'']]]
];
