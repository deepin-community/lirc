var searchData=
[
  ['keypresses_690',['keypresses',['../structlengths__state.html#a5ba133f3076964dba14d621d8be2a335',1,'lengths_state']]],
  ['keypresses_5fdone_691',['keypresses_done',['../structlengths__state.html#a2044804fca25b7d5daa57bbc3a44605a',1,'lengths_state']]]
];
