var searchData=
[
  ['option_5ft_451',['option_t',['../structoption__t.html',1,'']]],
  ['opts_452',['opts',['../structopts.html',1,'']]]
];
