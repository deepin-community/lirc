var searchData=
[
  ['_5fdictionary_5f_432',['_dictionary_',['../struct__dictionary__.html',1,'']]]
];
