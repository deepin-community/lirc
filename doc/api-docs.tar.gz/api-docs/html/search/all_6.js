var searchData=
[
  ['fd_133',['fd',['../structdriver.html#a277e91c9ef0365654b5412cdcf8cac5f',1,'driver']]],
  ['features_134',['features',['../structdriver.html#a551a50b0badb7c038dbea018038637e8',1,'driver']]],
  ['flag_135',['flag',['../structflaglist.html#afe3283978a321862c7c7705e13206672',1,'flaglist']]],
  ['flaglist_136',['flaglist',['../structflaglist.html',1,'']]],
  ['flags_137',['flags',['../structir__remote.html#a9ac03eb6d4cee793010b00fe434aa985',1,'ir_remote']]],
  ['flushhw_138',['flushhw',['../irrecord_8c.html#a198cace7ef605b777b3e14fc8289426b',1,'flushhw(void):&#160;irrecord.c'],['../irrecord_8h.html#a198cace7ef605b777b3e14fc8289426b',1,'flushhw(void):&#160;irrecord.c']]],
  ['for_5feach_5fdriver_139',['for_each_driver',['../drv__admin_8h.html#a20c8785b0c4a112a87b05eec158ecef7',1,'for_each_driver(drv_guest_func func, void *arg, const char *pluginpath):&#160;drv_admin.c'],['../drv__admin_8c.html#a20c8785b0c4a112a87b05eec158ecef7',1,'for_each_driver(drv_guest_func func, void *arg, const char *pluginpath):&#160;drv_admin.c']]],
  ['for_5feach_5fplugin_140',['for_each_plugin',['../drv__admin_8c.html#aac333496b18370092de4b8a1efde53d5',1,'for_each_plugin(plugin_guest_func plugin_guest, void *arg, const char *pluginpath):&#160;drv_admin.c'],['../drv__admin_8h.html#aac333496b18370092de4b8a1efde53d5',1,'for_each_plugin(plugin_guest_func plugin_guest, void *arg, const char *pluginpath):&#160;drv_admin.c']]],
  ['for_5feach_5fremote_141',['for_each_remote',['../irrecord_8c.html#aeeb91096305a1eae213eba243cb6d197',1,'for_each_remote(struct ir_remote *remotes, remote_func func):&#160;irrecord.c'],['../irrecord_8h.html#aeeb91096305a1eae213eba243cb6d197',1,'for_each_remote(struct ir_remote *remotes, remote_func func):&#160;irrecord.c']]],
  ['free_5fall_5flengths_142',['free_all_lengths',['../irrecord_8c.html#ac048f7ba69dba23c70e40057961428be',1,'free_all_lengths(void):&#160;irrecord.c'],['../irrecord_8h.html#ac048f7ba69dba23c70e40057961428be',1,'free_all_lengths(void):&#160;irrecord.c']]],
  ['free_5fconfig_143',['free_config',['../group__private__api.html#gaa55b7dcba60df4c178fd885eaf129288',1,'free_config(struct ir_remote *remotes):&#160;config_file.c'],['../group__private__api.html#gaa55b7dcba60df4c178fd885eaf129288',1,'free_config(struct ir_remote *remotes):&#160;config_file.c']]],
  ['freq_144',['freq',['../structir__remote.html#a04eb04a7c2333f53ceb20ffef8d2ebc4',1,'ir_remote']]]
];
