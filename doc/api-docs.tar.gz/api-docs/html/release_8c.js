var release_8c =
[
    [ "get_release_data", "release_8c.html#a23a8de91939f2b0c4ee9566e15f145d8", null ],
    [ "get_release_time", "release_8c.html#acd5db5a332efcd97e52621b7dc4db2a3", null ],
    [ "register_button_press", "release_8c.html#a3b06cf75f596a29a84d1137c05b62efe", null ]
];